// scripts/wipe-all-except-users-and-settings.ts
// npx tsx scripts/wipe-all-except-users-and-settings.ts
import "dotenv/config";
import { prisma } from "@/lib/prisma";

const DRY_RUN = false; // 👈 Pehle true rakhein

console.log(
  process.env.DATABASE_URL
    ? "✅ DATABASE_URL Loaded"
    : "❌ DATABASE_URL Missing",
);

async function main() {
  const counts = {
    followUp: await prisma.followUp.count(),
    statusHistory: await prisma.statusHistory.count(),
    activityLog: await prisma.activityLog.count(),
    notification: await prisma.notification.count(),
    lead: await prisma.lead.count(),
    announcement: await prisma.announcement.count(),
    exportLog: await prisma.exportLog.count(),
  };

  console.log("\nCurrent row counts (jo delete honge):");
  console.table(counts);

  const userCount = await prisma.user.count();
  const settingCount = await prisma.cRMSetting.count();

  console.log(
    `\nSafe rahenge (delete NAHI honge): User = ${userCount}, CRMSetting = ${settingCount}\n`,
  );

  if (DRY_RUN) {
    console.log("⚠️ DRY_RUN=true hai — kuch bhi delete nahi hua.");
    console.log(
      "Counts sahi lag rahe hain to DRY_RUN=false karke dobara run karein.\n",
    );
    return;
  }

  const result = await prisma.$transaction([
    prisma.followUp.deleteMany({}),
    prisma.statusHistory.deleteMany({}),
    prisma.activityLog.deleteMany({}),
    prisma.notification.deleteMany({}),
    prisma.exportLog.deleteMany({}),
    prisma.announcement.deleteMany({}),
    prisma.lead.deleteMany({}),
  ]);

  console.log("\n✅ Deleted:");
  console.log(`FollowUp:      ${result[0].count}`);
  console.log(`StatusHistory: ${result[1].count}`);
  console.log(`ActivityLog:   ${result[2].count}`);
  console.log(`Notification:  ${result[3].count}`);
  console.log(`ExportLog:     ${result[4].count}`);
  console.log(`Announcement:  ${result[5].count}`);
  console.log(`Lead:          ${result[6].count}`);

  console.log("\n✅ User aur CRMSetting untouched rahe.\n");
}

main()
  .then(async () => {
    await prisma.$disconnect();
    process.exit(0);
  })
  .catch(async (err) => {
    console.error("\n❌ Error:");
    console.error(err);
    console.error("\nRaw Error:");
    console.error(JSON.stringify(err, null, 2));

    await prisma.$disconnect();
    process.exit(1);
  });
