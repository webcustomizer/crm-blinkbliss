import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAuth } from "@/lib/require-auth";

export const dynamic = "force-dynamic";

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ id: string }> },
) {
  try {
    const auth = await requireAuth(req, ["ADMIN"]);
    if ("error" in auth) return auth.error;
    const { id } = await context.params;
    const lead = await prisma.lead.findUnique({
      where: { id },
      include: {
        assignedTo: { select: { id: true, name: true } },
        followups: {
          orderBy: { createdAt: "desc" },
          include: { user: { select: { id: true, name: true } } },
        },
        statusHistory: {
          orderBy: { changedAt: "desc" },
          include: { changedBy: { select: { id: true, name: true } } },
        },
      },
    });

    if (!lead) {
      return NextResponse.json({ success: false, message: "Lead not found" }, { status: 404 });
    }

    // Auto dead check
    const setting = await prisma.cRMSetting.findFirst();
    if (
      setting &&
      lead.followUpCount >= (setting.maxFollowUps ?? 3) &&
      lead.nextFollowUp &&
      new Date() >= new Date(lead.nextFollowUp) &&
      lead.status !== "JOINED" &&
      lead.status !== "DEAD"
    ) {
      await prisma.lead.update({
        where: { id: lead.id },
        data: { status: "DEAD", nextFollowUp: null },
      });
      lead.status = "DEAD";
      lead.nextFollowUp = null;
    }

    return NextResponse.json({ success: true, data: lead });
  } catch (error) {
    return NextResponse.json({ success: false, message: "Failed to get lead" }, { status: 500 });
  }
}

export async function PATCH(
  req: NextRequest,
  context: { params: Promise<{ id: string }> },
) {
  try {
    const auth = await requireAuth(req, ["ADMIN"]);
    if ("error" in auth) return auth.error;
    const currentUser = auth.user;
    const { id } = await context.params;
    const body = await req.json();
    const oldLead = await prisma.lead.findUnique({ where: { id } });

    if (!oldLead) {
      return NextResponse.json({ success: false, message: "Lead not found" }, { status: 404 });
    }

    // DEAD -> NEW reset
    const isDeadToNewReset = oldLead.status === "DEAD" && body.status === "NEW";
    let resetUpdate: any = {};
    if (isDeadToNewReset) {
      await prisma.followUp.deleteMany({ where: { leadId: id } });
      await prisma.statusHistory.deleteMany({ where: { leadId: id } });
      resetUpdate = { followUpCount: 0, lastFollowUp: null, nextFollowUp: null, remarks: null };
    }

    let followUpUpdate: any = {};
    if (body.followUpDone === true) {
      const setting = await prisma.cRMSetting.findFirst();
      const currentCount = oldLead.followUpCount || 0;
      const newCount = currentCount + 1;
      const maxFollowUps = setting?.maxFollowUps ?? 3;
      const nextStatus = oldLead.status;
      let days = 0;

      if (currentCount === 0) days = setting?.firstFollowUpDays ?? 7;
      else if (currentCount === 1) days = setting?.secondFollowUpDays ?? 15;
      else if (currentCount === 2) days = setting?.thirdFollowUpDays ?? 30;
      else days = setting?.thirdFollowUpDays ?? 30;

      let nextFollowUp: Date | null = null;
      if (newCount < maxFollowUps) {
        nextFollowUp = new Date();
        nextFollowUp.setDate(nextFollowUp.getDate() + days);
      }

      await prisma.followUp.create({
        data: {
          remarks: body.remarks || "Follow up completed",
          followUpNumber: newCount,
          nextFollowUp,
          leadId: id,
          userId: currentUser.id,
        },
      });

      followUpUpdate = {
        followUpCount: newCount,
        lastFollowUp: new Date(),
        status: nextStatus,
        nextFollowUp,
      };
    }

    // Track first response time (SLA)
    let slaUpdate: any = {};
    if ((body.status && body.status !== "NEW") || body.followUpDone || body.remarks) {
      if (!oldLead.firstResponseAt) {
        slaUpdate.firstResponseAt = new Date();
      }
    }

    const updatedLead = await prisma.lead.update({
      where: { id },
      data: isDeadToNewReset
        ? { status: body.status, ...resetUpdate }
        : {
            ...(body.name !== undefined && { name: body.name }),
            ...(body.phone !== undefined && { phone: body.phone }),
            ...(body.email !== undefined && { email: body.email }),
            ...(body.city !== undefined && { city: body.city }),
            ...(body.age !== undefined && { age: body.age }),
            ...(body.purpose !== undefined && { purpose: body.purpose }),
            ...(body.currentStatus !== undefined && { currentStatus: body.currentStatus }),
            ...(body.bestTimeToReach !== undefined && { bestTimeToReach: body.bestTimeToReach }),
            ...(body.willingToAttendTraining !== undefined && { willingToAttendTraining: body.willingToAttendTraining }),
            ...(body.source !== undefined && { source: body.source }),
            ...(body.status !== undefined && { status: body.status }),
            ...(body.remarks !== undefined && { remarks: body.remarks }),
            ...(body.assignedToId !== undefined && { assignedToId: body.assignedToId || null }),
            ...(body.nextFollowUp !== undefined && { nextFollowUp: body.nextFollowUp ? new Date(body.nextFollowUp) : null }),
            ...followUpUpdate,
            ...slaUpdate,
          },
    });

    const finalStatus = followUpUpdate.status || body.status;
    if (!isDeadToNewReset && finalStatus && oldLead.status !== finalStatus) {
      await prisma.statusHistory.create({
        data: {
          leadId: id,
          oldStatus: oldLead.status,
          newStatus: finalStatus,
          changedById: currentUser.id,
        },
      });
    }

    return NextResponse.json({ success: true, message: "Lead updated successfully", data: updatedLead });
  } catch (error) {
    return NextResponse.json({ success: false, message: "Failed to update lead" }, { status: 500 });
  }
}
